import os
import json
import argparse
from os.path import abspath, join

import pandas as pd
from gensim.models import KeyedVectors

from utils.eval import Evaluator
from utils.data import TextPreprocessor
from models.lexical_models import TFIDFRetriever, BM25Retriever, SWSNRetriever, BM25Official
from models.zeroshot_dense_models import Word2vecRetriever, FasttextRetriever, BERTRetriever

def main(args):
    print("Loading questions and articles...")
    dfA = pd.read_csv(args.articles_path)
    print("LEN DFA: " + str(len(dfA)))
    dfQ_test = pd.read_csv(args.test_questions_path)
    ground_truths = dfQ_test['article_ids'].apply(lambda x: list(map(int, x.split(',')))).tolist()
    if not args.retriever == 'bert':
        print("Preprocessing articles and questions (lemmatizing={})...".format(args.lem))
        if args.lem:
            articles = pd.read_pickle('../../../fr_lem_articles.pkl')
            questions = pd.read_pickle('../../../fr_lem_questions.pkl')
        else:
            cleaner = TextPreprocessor(spacy_model="fr_core_news_md")
            articles = cleaner.preprocess(dfA['article'], lemmatize=args.lem)
            questions = cleaner.preprocess(dfQ_test['question'], lemmatize=args.lem)
    else:
        articles = dfA['article'].tolist()
        questions = dfQ_test['question'].tolist()

    print("Initializing the {} retriever model...".format(args.retriever))
    if args.retriever == 'tfidf':
        retriever = TFIDFRetriever(retrieval_corpus=articles)
    if args.retriever == 'bm25Official':
        retriever = BM25Official(retrieval_corpus=articles)
    elif args.retriever == 'bm25':
        # retriever = BM25Retriever(retrieval_corpus=articles, k1=1.0, b=0.6)
        retriever = BM25Retriever(retrieval_corpus=articles, k1=1.2, b=0.6)
    elif args.retriever == 'word2vec':
        best_checkpoint = abspath(join(__file__, "../embeddings/word2vec/non_lemmatized/frWac_non_lem_no_postag_no_phrase_500_skip_cut100.bin"))
        # best_checkpoint = abspath(join(__file__, "../embeddings/word2vec/lemmatized/frWac_no_postag_no_phrase_500_skip_cut100.bin"))
        retriever = Word2vecRetriever(model_path_or_name=best_checkpoint, pooling_strategy='mean', retrieval_corpus=articles)
    elif args.retriever == 'fasttext':
        best_checkpoint = abspath(join(__file__, "../embeddings/fasttext/french/cc.fr.300.bin"))
        retriever = FasttextRetriever(model_path_or_name=best_checkpoint, pooling_strategy='mean', retrieval_corpus=articles)
    elif args.retriever == 'bert':
        retriever = BERTRetriever(model_path_or_name='camembert-base', pooling_strategy='mean', retrieval_corpus=articles)

    print("Running model on test questions...")
    if args.retriever == 'tfidf' or args.retriever == 'bm25' or args.retriever== 'bm25Official':
        retrieved_docs = retriever.search_all(questions, top_k=500)
    else:
        retrieved_docs = retriever.search_all(questions, top_k=500, dist_metric='cosine')
    
    print("Computing the retrieval scores...")
    evaluator = Evaluator()
    scores = evaluator.compute_all_metrics(retrieved_docs, ground_truths)
    
    print("Saving the scores to {} ...".format(args.output_dir))
    os.makedirs(args.output_dir, exist_ok=True)
    with open(join(args.output_dir, f'{args.retriever}_test_results.json'), 'w') as f:
        json.dump(scores, f, indent=2)

    with open(join(args.output_dir, f'{args.retriever}_y_docs.json'), 'w') as f:
        json.dump(retrieved_docs.tolist(), f)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--articles_path", 
                        type=str, 
                        default=abspath(join(__file__, "../../../new_data/french/fr_articles.csv")),
                        help="Path of the data file containing the law articles."
    )
    parser.add_argument("--test_questions_path", 
                        type=str, 
                        default=abspath(join(__file__, "../../../../new_data/french/fr_test.csv")),
                        help="Path of the data file containing the test questions."
    )
    parser.add_argument("--lem",
                        action='store_true', 
                        default=False,
                        help="Lemmatize the questions and articles for retrieval."
    )
    parser.add_argument("--retriever", 
                        type=str,
                        choices=["tfidf","bm25", "bm25Official", "word2vec","fasttext","bert"],
                        required=True,
                        help="The type of model to use for retrieval"
    )
    parser.add_argument("--output_dir",
                        type=str, 
                        default=abspath(join(__file__, "../output/zeroshot/test-run/")),
                        help="Path of the output directory."
    )
    args, _ = parser.parse_known_args()
    main(args)
